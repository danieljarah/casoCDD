En esta carpeta se encuentran los archivos necesarios para correr Codigo entregable.ipynb

Es importante destacar que este código funciona correctamente en python 3.11.5 con las bibliotecas presentes en el archivo de requirements.txt